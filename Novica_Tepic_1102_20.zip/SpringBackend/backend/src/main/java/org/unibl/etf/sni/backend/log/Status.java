package org.unibl.etf.sni.backend.log;

public enum Status {
    DANGER,
    CHANGED,
    CORRECT,
    ERROR

}

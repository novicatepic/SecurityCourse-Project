package org.unibl.etf.sni.backend.exception;

public class InvalidUsernameException extends Exception {
}

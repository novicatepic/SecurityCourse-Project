package org.unibl.etf.sni.backend.exception;

public class PasswordTooShortException extends Exception {
}

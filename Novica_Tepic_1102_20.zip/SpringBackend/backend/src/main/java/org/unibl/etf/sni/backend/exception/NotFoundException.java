package org.unibl.etf.sni.backend.exception;

public class NotFoundException extends Exception {
}

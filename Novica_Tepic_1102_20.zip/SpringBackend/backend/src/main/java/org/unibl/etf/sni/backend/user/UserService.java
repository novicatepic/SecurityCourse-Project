package org.unibl.etf.sni.backend.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.unibl.etf.sni.backend.exception.NotFoundException;
import org.unibl.etf.sni.backend.exception.PasswordTooShortException;
import org.unibl.etf.sni.backend.exception.RegistrationNotAllowed;

import javax.swing.text.html.Option;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("User not found."));
    }

    public static PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public UserModel registerUser(UserModel user) throws RegistrationNotAllowed, PasswordTooShortException {

        if(user.getPassword().length() < 8) {
            throw new PasswordTooShortException();
        }

        Optional<UserModel> optUser = userRepository.findByEmail(user.getEmail());
        if(optUser.isPresent()) {
            throw new RegistrationNotAllowed();
        }
        Optional<UserModel> optUser2 = userRepository.findByUsername(user.getUsername());
        if(optUser2.isPresent()) {
            throw new RegistrationNotAllowed();
        }

        user.setPassword(passwordEncoder().encode(user.getPassword()) );
        user.setActive(false);
        return userRepository.save(user);
    }

    public UserModel findByUserId(Integer id) throws NotFoundException {
        return userRepository.findById(id).orElseThrow(NotFoundException::new);
    }

    public UserModel findByEmail(String email) throws NotFoundException {
        return userRepository.findByEmail(email).orElseThrow(NotFoundException::new);
    }

}

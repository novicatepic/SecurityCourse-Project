package org.unibl.etf.sni.backend.room;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.unibl.etf.sni.backend.comment.CommentModel;
import org.unibl.etf.sni.backend.comment.CommentRepository;
import org.unibl.etf.sni.backend.exception.NotFoundException;

import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private CommentRepository commentRepository;

    public List<CommentModel> getCommentsForRoom(Integer roomId) {
        return commentRepository.findAll().stream().filter((x) -> x.getRoomId()==roomId && x.getEnabled() && !x.getForbidden())
                .toList();
    }

    public List<RoomModel> getAllRooms() {
        return roomRepository.findAll();
    }

    public RoomModel getRoomById(Integer roomId) throws NotFoundException {
        return roomRepository.findById(roomId).orElseThrow(NotFoundException::new);
    }
}

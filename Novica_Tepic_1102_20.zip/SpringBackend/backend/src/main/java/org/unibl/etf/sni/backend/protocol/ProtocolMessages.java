package org.unibl.etf.sni.backend.protocol;

public enum ProtocolMessages {

    OK,
    NOT_OK_SECOND_LEVEL,
    NOT_OK_FIRST_LEVEL

}

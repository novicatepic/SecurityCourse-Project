package org.unibl.etf.sni.backend.role;

public enum Role {

    ROLE_UNDEFINED,
    ROLE_ADMIN,
    ROLE_MODERATOR,
    ROLE_FORUM

}

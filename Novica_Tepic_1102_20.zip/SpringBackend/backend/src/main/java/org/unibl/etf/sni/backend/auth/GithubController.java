package org.unibl.etf.sni.backend.auth;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.catalina.User;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.unibl.etf.sni.backend.exception.NotFoundException;
import org.unibl.etf.sni.backend.user.UserModel;
import org.unibl.etf.sni.backend.user.UserService;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

//logging in with github
//accessing email and username
//if user doesn't exists, admin needs to enable his account, else he logs in
@CrossOrigin("https://localhost:4200")
@RestController
@RequestMapping("/api")
public class GithubController {

    @Value("${spring.github.clientId}")
    private String clientId;

    @Value("${spring.github.clientSecret}")
    private String clientSecret;

    @Value("${spring.github.redirectUri}")
    private String redirectUri;

    @Autowired
    private UserService userService;

    private final AuthenticationService authenticationService;

    public GithubController(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @GetMapping("/callback")
    public ResponseEntity<JwtAuthResponse> callback(@RequestParam String code) throws URISyntaxException, IOException, NotFoundException {
        // Construct the request URL
        URI uri = new URIBuilder("https://github.com/login/oauth/access_token")
                .addParameter("client_id", clientId)
                .addParameter("client_secret", clientSecret)
                .addParameter("code", code)
                .addParameter("redirect_uri", redirectUri)
                .build();

        // Create an HTTP POST request
        org.apache.http.client.HttpClient client = HttpClientBuilder.create().build();
        HttpPost postRequest = new HttpPost(uri);
        postRequest.setEntity(new StringEntity("", ContentType.APPLICATION_FORM_URLENCODED));

        // Send the request and get the response
        HttpResponse response = client.execute(postRequest);

        // Get the response body as a string
        HttpEntity entity = response.getEntity();
        String responseBody = EntityUtils.toString(entity);
        String accessToken = extractAccessToken(responseBody);
        String userDetails = getUserDetails(accessToken);
        String email = extractEmail(userDetails);
        String username = extractLogin(userDetails);

        return new ResponseEntity<>(authenticationService.githubMailLogin(email, username), HttpStatus.OK);
    }

    private String extractAccessToken(String responseBody) {
        String prefix = "access_token=";
        String suffix = "&scope";
        int startIndex = responseBody.indexOf(prefix);
        int endIndex = responseBody.indexOf(suffix);
        if (startIndex != -1 && endIndex != -1 && startIndex < endIndex) {
            return responseBody.substring(startIndex + prefix.length(), endIndex);
        }
        return null; // Return null if the access token cannot be extracted
    }

    private String getUserDetails(String accessToken) throws URISyntaxException, IOException {
        URI uri = new URIBuilder("https://api.github.com/user")
                .build();

        // Create an HTTP GET request
        CloseableHttpClient client =  HttpClientBuilder.create().build();
        HttpGet getRequest = new HttpGet(uri);
        getRequest.setHeader("Authorization", "Bearer " + accessToken);

        // Send the request and get the response
        CloseableHttpResponse response = client.execute(getRequest);

        // Get the response body as a string
        HttpEntity entity = response.getEntity();
        String responseBody = EntityUtils.toString(entity);

        // Return the response body to the caller
        return responseBody;
    }


    private String extractEmail(String userDetails) {
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(userDetails, JsonObject.class);

        if (jsonObject.has("email")) {
            return jsonObject.get("email").getAsString();
        }

        return null;
    }

    private String extractLogin(String userDetails) {
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(userDetails, JsonObject.class);

        if (jsonObject.has("login")) {
            return jsonObject.get("login").getAsString();
        }
        return null;
    }

}

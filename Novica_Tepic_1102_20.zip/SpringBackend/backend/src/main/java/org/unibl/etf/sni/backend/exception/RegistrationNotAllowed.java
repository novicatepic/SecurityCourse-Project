package org.unibl.etf.sni.backend.exception;

public class RegistrationNotAllowed extends Exception {
}

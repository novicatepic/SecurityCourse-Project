import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Comment } from '../model/Comment';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class NewCommentService {

  private commentUrl = environment.newCommentUrl;

  constructor(private http:HttpClient) { }


  saveComment(comment: Comment): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post(`${this.commentUrl}`, JSON.stringify(comment), {headers});
  }

  deleteComment(id: any, userId: any, roomId: any) : Observable<any> {
    const url = this.commentUrl + "/" + id + "/" + userId + "/" + roomId;
    return this.http.delete(`${url}`);
  }

  updateComment(comment: Comment) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.patch(`${this.commentUrl}`, JSON.stringify(comment), {headers});
  }

}

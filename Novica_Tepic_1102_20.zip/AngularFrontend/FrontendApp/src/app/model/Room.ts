export class Room {
    id?: number;
    name?: string;

    constructor() {

    }

}